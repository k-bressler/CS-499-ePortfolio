# Example Python Code to Insert a Document 

#Kaitlin Bressler
#CS340 Fall 2025

#import libraries
from pymongo import MongoClient 
from bson.objectid import ObjectId 
from pymongo.errors import PyMongoError

class AnimalShelter(object): 
    """ CRUD operations for Animal collection in MongoDB """ 

    def __init__(self, USER, PASS, HOST, PORT, DB, COL): 
        # Initializing the MongoClient. This helps to access the MongoDB 
        # databases and collections. This is hard-wired to use the aac 
        # database, the animals collection, and the aac user. 
        # 
        # You must edit the password below for your environment. 
        # 
        # Connection Variables 
        # 
        USER = 'aacuser' 
        PASS = 'SNHU1234' 
        HOST = 'localhost' 
        PORT = 27017 
        DB = 'AAC' 
        COL = 'animals' 
        # 
        # Initialize Connection 
        # 
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT)) 
        self.database = self.client['%s' % (DB)] 
        self.collection = self.database['%s' % (COL)] 

    ##########################################################
    #METHOD: next record number
    #a method to return the next available record number for use in the create method
    ##########################################################
    
    def next_record_number(self):
        
        try: 
            last_record = self.collection.find_one(
                {},
                sort=[("rec_num", -1)]
            )
    
            if last_record is None:
                return 1
        
            return last_record["rec_num"] +1
    
        except Exception as e:
            print("Error getting next record number:", e)
            return None
            
    ##########################################################
    #CREATE (insert new document)
    #insert document, return if successful, else false
    ##########################################################
    
    def create(self, data):
        
        if data is None: 
            raise Exception("Nothing to save, because data parameter is empty") 
            
        try: 
            data["rec_num"] = self.next_record_number()
            
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        
        except PyMongoError as e:
            print("Insert failed", e)
            return False

    ##########################################################
    #READ (query documents)
    #query documents using key/value lookup
    ##########################################################
    
    def read(self, query):
        
        try:
            cursor = self.collection.find(query)
            results = [doc for doc in cursor]
            return results
        
        except PyMongoError as e:
            print("Query failed", e)
            return []
    
    ##########################################################
    #UPDATE (modify document)
    #Modifies document(s) that match query
    ##########################################################
    
    def update(self, query, new_values, many=False):
        
        if query is None or new_values is None:
            raise Exception("Query & update values cannot be empty")
            
        try:
            if many:
                result = self.collection.update_many(query, {"$set": new_values})
            else:
                result = self.collection.update_one(query, {"$set": new_values})
                
            return result.modified_count
    
        except PyMongoError as e:
            print("Update failed", e)
            return 0
    
    ##########################################################
    #DELETE (delete document)
    #remove document(s) that match query
    ##########################################################
    
    def delete(self, query, many=False):
        
        if query is None:
            raise Exception("Query parameter cannot be empty")
            
        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)
                
            return result.deleted_count
        
        except PyMongoError as e:
            print("Delete failed", e)
            return 0
    